export const handler = async () => {
  throw new Error('Código aún no desplegado por el pipeline de Lambdas');
};
